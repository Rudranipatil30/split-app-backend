import os
import logging
from flask import Flask, render_template, request, jsonify
from flask_cors import CORS
from expense_manager import ExpenseManager

# Configure logging
logging.basicConfig(level=logging.DEBUG)

# Create Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key-change-in-production")

# Enable CORS
CORS(app)

# Initialize expense manager
expense_manager = ExpenseManager()

@app.route('/')
def index():
    """Serve the main web interface"""
    return render_template('index.html')

@app.route('/api/expenses', methods=['GET'])
def get_expenses():
    """Get all expenses"""
    try:
        expenses = expense_manager.get_all_expenses()
        return jsonify({
            'success': True,
            'expenses': expenses
        })
    except Exception as e:
        logging.error(f"Error getting expenses: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Failed to retrieve expenses'
        }), 500

@app.route('/api/expenses', methods=['POST'])
def add_expense():
    """Add a new expense"""
    try:
        data = request.get_json()
        
        # Validate required fields
        if not data or not all(key in data for key in ['description', 'amount', 'participants']):
            return jsonify({
                'success': False,
                'error': 'Missing required fields: description, amount, participants'
            }), 400
        
        # Validate amount
        try:
            amount = float(data['amount'])
            if amount <= 0:
                raise ValueError("Amount must be positive")
        except (ValueError, TypeError):
            return jsonify({
                'success': False,
                'error': 'Invalid amount. Must be a positive number.'
            }), 400
        
        # Validate participants
        participants = data['participants']
        if not isinstance(participants, list) or len(participants) < 2:
            return jsonify({
                'success': False,
                'error': 'At least 2 participants are required'
            }), 400
        
        # Clean participant names
        participants = [p.strip() for p in participants if p.strip()]
        if len(participants) < 2:
            return jsonify({
                'success': False,
                'error': 'At least 2 valid participants are required'
            }), 400
        
        # Add expense
        expense_id = expense_manager.add_expense(
            description=data['description'].strip(),
            amount=amount,
            participants=participants,
            paid_by=data.get('paid_by', participants[0]).strip()
        )
        
        return jsonify({
            'success': True,
            'expense_id': expense_id,
            'message': 'Expense added successfully'
        })
        
    except Exception as e:
        logging.error(f"Error adding expense: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Failed to add expense'
        }), 500

@app.route('/api/expenses/<int:expense_id>', methods=['PUT'])
def update_expense(expense_id):
    """Update an existing expense"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'error': 'No data provided'
            }), 400
        
        # Validate amount if provided
        if 'amount' in data:
            try:
                amount = float(data['amount'])
                if amount <= 0:
                    raise ValueError("Amount must be positive")
                data['amount'] = amount
            except (ValueError, TypeError):
                return jsonify({
                    'success': False,
                    'error': 'Invalid amount. Must be a positive number.'
                }), 400
        
        # Validate participants if provided
        if 'participants' in data:
            participants = data['participants']
            if not isinstance(participants, list) or len(participants) < 2:
                return jsonify({
                    'success': False,
                    'error': 'At least 2 participants are required'
                }), 400
            
            participants = [p.strip() for p in participants if p.strip()]
            if len(participants) < 2:
                return jsonify({
                    'success': False,
                    'error': 'At least 2 valid participants are required'
                }), 400
            data['participants'] = participants
        
        # Update expense
        success = expense_manager.update_expense(expense_id, data)
        
        if success:
            return jsonify({
                'success': True,
                'message': 'Expense updated successfully'
            })
        else:
            return jsonify({
                'success': False,
                'error': 'Expense not found'
            }), 404
            
    except Exception as e:
        logging.error(f"Error updating expense: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Failed to update expense'
        }), 500

@app.route('/api/expenses/<int:expense_id>', methods=['DELETE'])
def delete_expense(expense_id):
    """Delete an expense"""
    try:
        success = expense_manager.delete_expense(expense_id)
        
        if success:
            return jsonify({
                'success': True,
                'message': 'Expense deleted successfully'
            })
        else:
            return jsonify({
                'success': False,
                'error': 'Expense not found'
            }), 404
            
    except Exception as e:
        logging.error(f"Error deleting expense: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Failed to delete expense'
        }), 500

@app.route('/api/balances', methods=['GET'])
def get_balances():
    """Get balance information for all participants"""
    try:
        balances = expense_manager.calculate_balances()
        settlements = expense_manager.calculate_settlements()
        
        return jsonify({
            'success': True,
            'balances': balances,
            'settlements': settlements
        })
        
    except Exception as e:
        logging.error(f"Error calculating balances: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Failed to calculate balances'
        }), 500

@app.route('/api/participants', methods=['GET'])
def get_participants():
    """Get all participants"""
    try:
        participants = expense_manager.get_all_participants()
        return jsonify({
            'success': True,
            'participants': participants
        })
    except Exception as e:
        logging.error(f"Error getting participants: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Failed to retrieve participants'
        }), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
