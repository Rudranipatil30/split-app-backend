from datetime import datetime
from typing import Dict, List, Tuple
import logging

class ExpenseManager:
    """Manages expenses and calculations in memory"""
    
    def __init__(self):
        self.expenses = {}  # {expense_id: expense_dict}
        self.next_id = 1
        
    def add_expense(self, description: str, amount: float, participants: List[str], paid_by: str = None) -> int:
        """Add a new expense and return its ID"""
        if paid_by is None:
            paid_by = participants[0]
        
        # Ensure paid_by is in participants
        if paid_by not in participants:
            participants.append(paid_by)
        
        expense = {
            'id': self.next_id,
            'description': description,
            'amount': amount,
            'participants': participants,
            'paid_by': paid_by,
            'date_created': datetime.now().isoformat(),
            'date_updated': datetime.now().isoformat()
        }
        
        self.expenses[self.next_id] = expense
        expense_id = self.next_id
        self.next_id += 1
        
        logging.info(f"Added expense {expense_id}: {description} - ${amount:.2f}")
        return expense_id
    
    def update_expense(self, expense_id: int, updates: Dict) -> bool:
        """Update an existing expense"""
        if expense_id not in self.expenses:
            return False
        
        expense = self.expenses[expense_id]
        
        # Update allowed fields
        allowed_fields = ['description', 'amount', 'participants', 'paid_by']
        for field in allowed_fields:
            if field in updates:
                expense[field] = updates[field]
        
        # Ensure paid_by is in participants
        if 'paid_by' in updates or 'participants' in updates:
            if expense['paid_by'] not in expense['participants']:
                expense['participants'].append(expense['paid_by'])
        
        expense['date_updated'] = datetime.now().isoformat()
        
        logging.info(f"Updated expense {expense_id}")
        return True
    
    def delete_expense(self, expense_id: int) -> bool:
        """Delete an expense"""
        if expense_id not in self.expenses:
            return False
        
        del self.expenses[expense_id]
        logging.info(f"Deleted expense {expense_id}")
        return True
    
    def get_expense(self, expense_id: int) -> Dict:
        """Get a specific expense"""
        return self.expenses.get(expense_id)
    
    def get_all_expenses(self) -> List[Dict]:
        """Get all expenses sorted by date (newest first)"""
        expenses = list(self.expenses.values())
        expenses.sort(key=lambda x: x['date_created'], reverse=True)
        return expenses
    
    def get_all_participants(self) -> List[str]:
        """Get all unique participants across all expenses"""
        participants = set()
        for expense in self.expenses.values():
            participants.update(expense['participants'])
        return sorted(list(participants))
    
    def calculate_balances(self) -> Dict[str, float]:
        """Calculate how much each person owes or is owed"""
        balances = {}
        
        for expense in self.expenses.values():
            amount = expense['amount']
            participants = expense['participants']
            paid_by = expense['paid_by']
            
            # Calculate share per person
            share_per_person = amount / len(participants)
            
            # Initialize balances for new participants
            for participant in participants:
                if participant not in balances:
                    balances[participant] = 0.0
            
            # Person who paid gets credited
            balances[paid_by] += amount
            
            # Each participant owes their share
            for participant in participants:
                balances[participant] -= share_per_person
        
        # Round to 2 decimal places
        for person in balances:
            balances[person] = round(balances[person], 2)
        
        return balances
    
    def calculate_settlements(self) -> List[Dict]:
        """Calculate optimized settlements to minimize transactions"""
        balances = self.calculate_balances()
        
        # Separate creditors (positive balance) and debtors (negative balance)
        creditors = [(person, amount) for person, amount in balances.items() if amount > 0.01]
        debtors = [(person, -amount) for person, amount in balances.items() if amount < -0.01]
        
        # Sort by amount (largest first)
        creditors.sort(key=lambda x: x[1], reverse=True)
        debtors.sort(key=lambda x: x[1], reverse=True)
        
        settlements = []
        
        # Match debtors with creditors
        i, j = 0, 0
        while i < len(debtors) and j < len(creditors):
            debtor, debt_amount = debtors[i]
            creditor, credit_amount = creditors[j]
            
            # Calculate settlement amount
            settlement_amount = min(debt_amount, credit_amount)
            
            if settlement_amount > 0.01:  # Only include significant amounts
                settlements.append({
                    'from': debtor,
                    'to': creditor,
                    'amount': round(settlement_amount, 2)
                })
                
                # Update remaining amounts
                debtors[i] = (debtor, debt_amount - settlement_amount)
                creditors[j] = (creditor, credit_amount - settlement_amount)
            
            # Move to next debtor or creditor if current one is settled
            if debtors[i][1] < 0.01:
                i += 1
            if creditors[j][1] < 0.01:
                j += 1
        
        return settlements
