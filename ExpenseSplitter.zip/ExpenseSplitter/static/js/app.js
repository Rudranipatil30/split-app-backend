class ExpenseApp {
    constructor() {
        this.currentEditId = null;
        this.init();
    }

    init() {
        this.bindEvents();
        this.loadData();
    }

    bindEvents() {
        // Add expense form
        document.getElementById('expenseForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.addExpense();
        });

        // Edit expense form
        document.getElementById('saveExpenseBtn').addEventListener('click', () => {
            this.saveExpenseEdit();
        });

        // Tab change events
        document.querySelectorAll('#mainTabs button[data-bs-toggle="tab"]').forEach(tab => {
            tab.addEventListener('shown.bs.tab', () => {
                this.loadData();
            });
        });
    }

    async loadData() {
        await Promise.all([
            this.loadExpenses(),
            this.loadBalances()
        ]);
    }

    async addExpense() {
        const form = document.getElementById('expenseForm');
        const formData = new FormData(form);
        
        const participants = document.getElementById('participants').value
            .split(',')
            .map(p => p.trim())
            .filter(p => p.length > 0);

        const data = {
            description: formData.get('description') || document.getElementById('description').value,
            amount: parseFloat(document.getElementById('amount').value),
            paid_by: document.getElementById('paidBy').value.trim(),
            participants: participants
        };

        try {
            const response = await fetch('/api/expenses', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });

            const result = await response.json();

            if (result.success) {
                this.showAlert('Expense added successfully!', 'success');
                form.reset();
                await this.loadData();
            } else {
                this.showAlert(result.error || 'Failed to add expense', 'danger');
            }
        } catch (error) {
            console.error('Error adding expense:', error);
            this.showAlert('Failed to add expense. Please try again.', 'danger');
        }
    }

    async loadExpenses() {
        try {
            const response = await fetch('/api/expenses');
            const result = await response.json();

            if (result.success) {
                this.renderExpenses(result.expenses);
            } else {
                this.showAlert('Failed to load expenses', 'danger');
            }
        } catch (error) {
            console.error('Error loading expenses:', error);
            this.showAlert('Failed to load expenses', 'danger');
        }
    }

    async loadBalances() {
        try {
            const response = await fetch('/api/balances');
            const result = await response.json();

            if (result.success) {
                this.renderBalances(result.balances);
                this.renderSettlements(result.settlements);
            } else {
                this.showAlert('Failed to load balances', 'danger');
            }
        } catch (error) {
            console.error('Error loading balances:', error);
            this.showAlert('Failed to load balances', 'danger');
        }
    }

    renderExpenses(expenses) {
        const container = document.getElementById('expensesList');
        
        if (!expenses || expenses.length === 0) {
            container.innerHTML = `
                <div class="text-center text-muted py-4">
                    <i data-feather="inbox" class="mb-2"></i>
                    <p>No expenses added yet. Add your first expense above!</p>
                </div>
            `;
            feather.replace();
            return;
        }

        const expensesHtml = expenses.map(expense => {
            const date = new Date(expense.date_created).toLocaleDateString();
            const sharePerPerson = (expense.amount / expense.participants.length).toFixed(2);
            
            return `
                <div class="expense-item border-bottom pb-3 mb-3">
                    <div class="d-flex justify-content-between align-items-start">
                        <div class="flex-grow-1">
                            <h6 class="mb-1">${this.escapeHtml(expense.description)}</h6>
                            <div class="text-muted small mb-2">
                                <i data-feather="calendar" class="me-1"></i>
                                ${date}
                                <span class="ms-3">
                                    <i data-feather="user" class="me-1"></i>
                                    Paid by ${this.escapeHtml(expense.paid_by)}
                                </span>
                            </div>
                            <div class="mb-2">
                                <span class="badge bg-primary me-2">$${expense.amount.toFixed(2)}</span>
                                <span class="text-muted small">
                                    $${sharePerPerson} per person
                                </span>
                            </div>
                            <div class="small text-muted">
                                <i data-feather="users" class="me-1"></i>
                                ${expense.participants.map(p => this.escapeHtml(p)).join(', ')}
                            </div>
                        </div>
                        <div class="dropdown">
                            <button class="btn btn-sm btn-outline-secondary" type="button" 
                                    data-bs-toggle="dropdown">
                                <i data-feather="more-vertical"></i>
                            </button>
                            <ul class="dropdown-menu">
                                <li>
                                    <a class="dropdown-item" href="#" 
                                       onclick="app.editExpense(${expense.id})">
                                        <i data-feather="edit-2" class="me-2"></i>
                                        Edit
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item text-danger" href="#" 
                                       onclick="app.deleteExpense(${expense.id})">
                                        <i data-feather="trash-2" class="me-2"></i>
                                        Delete
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            `;
        }).join('');

        container.innerHTML = expensesHtml;
        feather.replace();
    }

    renderBalances(balances) {
        const container = document.getElementById('balancesList');
        
        if (!balances || Object.keys(balances).length === 0) {
            container.innerHTML = `
                <div class="text-center text-muted py-4">
                    <i data-feather="users" class="mb-2"></i>
                    <p>No participants yet. Add an expense to see balances!</p>
                </div>
            `;
            feather.replace();
            return;
        }

        const balanceItems = Object.entries(balances)
            .sort(([,a], [,b]) => b - a)
            .map(([person, balance]) => {
                const isOwed = balance > 0.01;
                const owes = balance < -0.01;
                const balanced = Math.abs(balance) <= 0.01;
                
                let badgeClass = 'bg-secondary';
                let icon = 'minus';
                let text = 'Settled';
                
                if (isOwed) {
                    badgeClass = 'bg-success';
                    icon = 'trending-up';
                    text = `Gets $${Math.abs(balance).toFixed(2)}`;
                } else if (owes) {
                    badgeClass = 'bg-warning';
                    icon = 'trending-down';
                    text = `Owes $${Math.abs(balance).toFixed(2)}`;
                }

                return `
                    <div class="d-flex justify-content-between align-items-center py-2 border-bottom">
                        <div>
                            <span class="fw-medium">${this.escapeHtml(person)}</span>
                        </div>
                        <div>
                            <span class="badge ${badgeClass}">
                                <i data-feather="${icon}" class="me-1"></i>
                                ${text}
                            </span>
                        </div>
                    </div>
                `;
            }).join('');

        container.innerHTML = balanceItems;
        feather.replace();
    }

    renderSettlements(settlements) {
        const container = document.getElementById('settlementsList');
        
        if (!settlements || settlements.length === 0) {
            container.innerHTML = `
                <div class="text-center text-muted py-4">
                    <i data-feather="check-circle" class="mb-2"></i>
                    <p>No settlements needed! Everyone is settled up.</p>
                </div>
            `;
            feather.replace();
            return;
        }

        const settlementsHtml = settlements.map(settlement => `
            <div class="settlement-item bg-light p-3 rounded mb-3">
                <div class="d-flex align-items-center justify-content-between">
                    <div class="d-flex align-items-center">
                        <div class="text-center me-3">
                            <i data-feather="arrow-right" class="text-primary"></i>
                        </div>
                        <div>
                            <strong>${this.escapeHtml(settlement.from)}</strong>
                            <span class="text-muted mx-2">pays</span>
                            <strong>${this.escapeHtml(settlement.to)}</strong>
                        </div>
                    </div>
                    <div>
                        <span class="badge bg-primary fs-6">
                            $${settlement.amount.toFixed(2)}
                        </span>
                    </div>
                </div>
            </div>
        `).join('');

        container.innerHTML = settlementsHtml;
        feather.replace();
    }

    editExpense(id) {
        // Find expense data
        fetch(`/api/expenses`)
            .then(response => response.json())
            .then(result => {
                if (result.success) {
                    const expense = result.expenses.find(e => e.id === id);
                    if (expense) {
                        this.currentEditId = id;
                        
                        // Populate edit form
                        document.getElementById('editExpenseId').value = id;
                        document.getElementById('editDescription').value = expense.description;
                        document.getElementById('editAmount').value = expense.amount;
                        document.getElementById('editPaidBy').value = expense.paid_by;
                        document.getElementById('editParticipants').value = expense.participants.join(', ');
                        
                        // Show modal
                        const modal = new bootstrap.Modal(document.getElementById('editExpenseModal'));
                        modal.show();
                    }
                }
            })
            .catch(error => {
                console.error('Error loading expense for edit:', error);
                this.showAlert('Failed to load expense data', 'danger');
            });
    }

    async saveExpenseEdit() {
        const id = this.currentEditId;
        const participants = document.getElementById('editParticipants').value
            .split(',')
            .map(p => p.trim())
            .filter(p => p.length > 0);

        const data = {
            description: document.getElementById('editDescription').value.trim(),
            amount: parseFloat(document.getElementById('editAmount').value),
            paid_by: document.getElementById('editPaidBy').value.trim(),
            participants: participants
        };

        try {
            const response = await fetch(`/api/expenses/${id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });

            const result = await response.json();

            if (result.success) {
                this.showAlert('Expense updated successfully!', 'success');
                
                // Hide modal
                const modal = bootstrap.Modal.getInstance(document.getElementById('editExpenseModal'));
                modal.hide();
                
                await this.loadData();
            } else {
                this.showAlert(result.error || 'Failed to update expense', 'danger');
            }
        } catch (error) {
            console.error('Error updating expense:', error);
            this.showAlert('Failed to update expense', 'danger');
        }
    }

    async deleteExpense(id) {
        if (!confirm('Are you sure you want to delete this expense?')) {
            return;
        }

        try {
            const response = await fetch(`/api/expenses/${id}`, {
                method: 'DELETE'
            });

            const result = await response.json();

            if (result.success) {
                this.showAlert('Expense deleted successfully!', 'success');
                await this.loadData();
            } else {
                this.showAlert(result.error || 'Failed to delete expense', 'danger');
            }
        } catch (error) {
            console.error('Error deleting expense:', error);
            this.showAlert('Failed to delete expense', 'danger');
        }
    }

    showAlert(message, type = 'info') {
        const alertContainer = document.getElementById('alertContainer');
        const alertId = `alert-${Date.now()}`;
        
        const alertHtml = `
            <div id="${alertId}" class="alert alert-${type} alert-dismissible fade show" role="alert">
                ${this.escapeHtml(message)}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        `;
        
        alertContainer.insertAdjacentHTML('beforeend', alertHtml);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            const alert = document.getElementById(alertId);
            if (alert) {
                const bsAlert = bootstrap.Alert.getInstance(alert);
                if (bsAlert) {
                    bsAlert.close();
                }
            }
        }, 5000);
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}

// Initialize the app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.app = new ExpenseApp();
});
